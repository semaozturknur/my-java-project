package ucakrevize;

public class Musteri {
    private String adSoyad;
    private String cinsiyet;
    private int yas;
    private boolean engelli;

    public Musteri(String adSoyad, String cinsiyet, int yas, boolean engelli) {
        this.adSoyad = adSoyad;
        this.cinsiyet = cinsiyet;
        this.yas = yas;
        this.engelli = engelli;
    }

  
}
