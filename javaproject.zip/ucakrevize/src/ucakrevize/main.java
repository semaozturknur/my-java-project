package ucakrevize;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		 // Müşteri bilgilerini kullanıcıdan alıyoruz. 
		
        System.out.println("Lütfen adınızı ve soyadınızı giriniz");
        String adSoyad = scanner.nextLine();

        System.out.print("Cinsiyetinizi girin (erkek/kadın): ");
        String cinsiyet = scanner.nextLine();

        System.out.println("Lütfen yaşınızı giriniz");
        int yas = scanner.nextInt();

        System.out.println("Engelli misiniz? (true/false)");
        boolean engelli = scanner.nextBoolean();

        System.out.println("Lokasyon için ülkeyi belirtiniz");
        String ulke = scanner.next();

        System.out.println(ulke + " içerisinde gitmek istediğiniz şehri belirtiniz.");
        String sehir = scanner.next();
        
        System.out.println("Lütfen istediğiniz tarih ve saati yazınız (dd/MM/yyyy HH:mm):");
        String tarihSaatStr = scanner.next();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        Date tarihSaat = null;
        try {
            tarihSaat = dateFormat.parse(tarihSaatStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }


        System.out.println("Koltuk numarası:");
        int koltukNo = scanner.nextInt();
        System.out.println(adSoyad + " adına " + tarihSaat + " tarihinde " + ulke + " adlı ülkeye " + sehir + " 'a " +
                "rezervasyonunuz yapılmıştır.Keyifli uçuşlar dileriiiiiiiiz. :)");

        scanner.close();

	}

}
