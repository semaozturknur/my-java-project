package ucakrevize;

import java.util.Date;

public class Rezervasyon {
    private Ucak ucak;
    private Lokasyon lokasyon;
    private Musteri musteri;
    private Date tarihSaat;
    private boolean acik;
    private int koltukNo;

    public Rezervasyon(Ucak ucak, Lokasyon lokasyon, Musteri musteri, Date tarihSaat, boolean acik, int koltukNo) {
        this.ucak = ucak;
        this.lokasyon = lokasyon;
        this.musteri = musteri;
        this.tarihSaat = tarihSaat;
        this.acik = acik;
        this.koltukNo = koltukNo;
    }
}